import json

def lambda_handler(event, context):
    print("Job Alerts Lambda started")

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Job Alerts Lambda is running successfully"
        })
    }
